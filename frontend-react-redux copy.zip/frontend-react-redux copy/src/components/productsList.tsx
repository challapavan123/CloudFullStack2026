//import {products} from '../data/products';
import React, { useEffect, useMemo, useState } from 'react';
import Ratings from './Ratings';
import { NavLink } from 'react-router-dom';
import type IProduct from '../model/product';

const ProductsList: React.FC = () => {
  const [products, setProducts] = useState<IProduct[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  useEffect(() => {
    fetch('http://localhost:5001/api/products')
      .then(response => response.json())
      .then(data => {
        setProducts(data);
         // Initialize filterProducts with the fetched data
      });
  },[]);

    const [showImages,setShowImages]  = useState(true);
   const filteredProducts = useMemo(() => {
       return products.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()))
       
      }, [products, searchTerm]);
  
  // const handleFilterChange = (event: 
  //   React.ChangeEvent<HTMLInputElement>) => {
  //   const filterValue = event.target.value.toLowerCase();
  //   const filteredProducts = 
  //   );
  //   setProducts(filteredProducts);
  // };
    return (
    <div className="card shadow-sm">
{/* HEADER */}
<div className="card-header">
<h5 className="mb-0">
Products ({products.length})
</h5>
</div>

<div className="card-body">
{/* SEARCH */}
<div className="row mb-3">
<div className="col-md-4">
<input
type="text"
className="form-control"
placeholder="Filter by product name" onChange={(e) => setSearchTerm(e.target.value)}  

/>
</div>
</div>

<div className="table-responsive">
<table className="table table-bordered table-hover align-middle">
{/* TABLE HEADER */}
<thead className="table-light">
<tr>
<th style={{ width: "90px" }}>Image</th>
<th>Product</th>
<th>Code</th>
<th>Available</th>
<th className="text-end">Price</th>
<th className="text-center">Rating</th>
</tr>
</thead>

<tbody>
{/* BUTTON ROW */}
<tr className="table-secondary">
<td>
<button
className="btn btn-sm btn-outline-primary"
onClick={() => setShowImages(!showImages)}
>
Toggle Images
</button>
</td>
<td colSpan={5}></td>
</tr>

{/* PRODUCTS */}
{filteredProducts.map(product => (
<tr key={product.id}>
<td className="text-center">
{showImages?
<img
src={product.imageUrl}
alt={product.name}
className="img-thumbnail"
style={{ maxWidth: "75px" }}
/>
: null}
</td>

<td className="fw-semibold">
<NavLink to={`/products/${product._id}`}>
{product.name}
</NavLink>
</td>

<td className="text-muted">
{product.productCode}
</td>

<td className="text-muted">
{product.productAvailable}
</td>

<td className="text-end">
{product.price.toFixed(2)}
</td>

<td className="text-center">
 <Ratings rating={parseFloat(product.rating?.toFixed(1) || '0')} />
</td>
</tr>
))}

{products.length === 0 && (
<tr>
<td colSpan={6} className="text-center text-muted">
No products found
</td>
</tr>
)}
</tbody>
</table>
</div>
</div>
</div>
)
}
  
      


export default ProductsList;